library(shiny)
ui <- fluidPage(
  titlePanel("Shiny Text"),
  sidebarLayout(
    sidebarPanel(
      selectInput(inputId="dataset",
                  label="데이터 셋 선택:",
                  choices=c("USArrests", "iris", "mtcars")),
      
      numericInput(inputId='obs',
                   label="관측치의 수",
                   value=10)
      
    ),
    mainPanel(
      verbatimTextOutput("summary"),
      tableOutput("view")
    )
  )
)

server <- function(input, output){ 
  datasetInput <- reactive({
    switch(input$dataset,
           "USArrests" = USArrests,
           "iris" = iris,
           "mtcars" = mtcars,2)
  })
  
  output$summary <- renderPrint({
    dataset <- datasetInput()
    summary(dataset)
  })
  
  output$view <- renderTable({
    head(datasetInput(), n=input$obs)
  })
}


shinyApp(ui=ui,server=server)
