library(shiny)
getwd()
setwd("C:/Users/201-4/Documents/drawplot")
shiny::runApp("drawplot")
